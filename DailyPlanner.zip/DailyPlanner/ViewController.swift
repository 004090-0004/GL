//
//  ViewController.swift
//  TODOAPP
//
//  Created by GOR GRIGORYAN on 2/9/20.
//  Copyright © 2020 GOR GRIGORYAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    var finalName = ""
    
    var timer:Timer?
    var timeLeft = 15
    
    @IBOutlet weak var GreetingName: UILabel!
    

    
    @IBOutlet weak var tableViewItem: UITableView!
    
    var items: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewItem.delegate = self
        tableViewItem.dataSource = self
        tableViewItem.rowHeight = 90
        
        
        GreetingName.text = "Hello \(self.finalName)!"
        
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.onTimerFires), userInfo: nil, repeats: true)
        
        
        
    }
    
    @IBAction func addItem(_ sender: Any) {
        let itemAlert = UIAlertController(title: "Add a Task", message: "Add a New Task", preferredStyle: .alert)
        itemAlert.addTextField()
        
        let addItemAction = UIAlertAction(title: "Add", style: .default) { (action) in
            let newItem = itemAlert.textFields![0]
            self.items.append(newItem.text!)
            self.tableViewItem.reloadData()
            
        }
                
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        itemAlert.addAction(addItemAction)
        itemAlert.addAction(cancelAction)
        
        present(itemAlert, animated: true, completion: nil  )
        
    }
    

    @objc func onTimerFires()
     {
         timeLeft -= 1

         if timeLeft <= 0 {
            timer!.invalidate()
             timer = nil
         }
     }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath) as! ItemCell
        
        cell.ItemLabel.text = items[indexPath.row]
        

        return cell
        
        }
        
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let cell = tableView.cellForRow(at: indexPath) as! ItemCell
    
    if cell.Done == false {
        cell.ItemImage.image = UIImage(named: "TickMark")
        cell.Done = true
    }
    else {
        cell.ItemImage.image = nil
        cell.Done = false
            }
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            items.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }
    
    
}
