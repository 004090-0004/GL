//
//  ItemCell.swift
//  TODOAPP
//
//  Created by GOR GRIGORYAN on 2/9/20.
//  Copyright © 2020 GOR GRIGORYAN. All rights reserved.
//

import UIKit

class ItemCell: UITableViewCell {
    @IBOutlet weak var ItemLabel: UILabel!
    @IBOutlet weak var ItemImage: UIImageView!
    
    var Done = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
