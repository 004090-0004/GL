//
//  DataSaved+CoreDataClass.swift
//  TODOAPP
//
//  Created by GOR GRIGORYAN on 3/7/20.
//  Copyright © 2020 GOR GRIGORYAN. All rights reserved.
//
//

import Foundation
import CoreData

@objc(DataSaved)
public class DataSaved: NSManagedObject {

}
