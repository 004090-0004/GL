//
//  DataSaved+CoreDataProperties.swift
//  TODOAPP
//
//  Created by GOR GRIGORYAN on 3/7/20.
//  Copyright © 2020 GOR GRIGORYAN. All rights reserved.
//
//

import Foundation
import CoreData


extension DataSaved {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DataSaved> {
        return NSFetchRequest<DataSaved>(entityName: "DataSaved")
    }

    @NSManaged public var cell: String?

}
