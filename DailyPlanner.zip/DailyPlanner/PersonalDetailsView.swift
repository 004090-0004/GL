//
//  LoginView.swift
//  TODOAPP
//
//  Created by GOR GRIGORYAN on 2/10/20.
//  Copyright © 2020 GOR GRIGORYAN. All rights reserved.
//

import Foundation
import UIKit

class LoginView: UIViewController {
    
    var userName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBOutlet weak var nameText: UITextField!
    
    
    
    @IBAction func Submit(_ sender: Any) {
        self.userName = nameText.text!
        performSegue(withIdentifier: "Name", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var Sender = segue.destination as! ViewController
        Sender.finalName = self.userName
        
    }
    
    
}

